# Exercice 2 - Questionnaire

1. Dans du JSX, quelles sont les caractères spéciaux utilisés pour déclarer du HTML ? du Javascript ?
    pour du html : React.createClass
    pour du js : 
    
2. En JSX, puis-je attribuer du code html tel que
`<h2>Mon Super Titre</h2>` à une variable JSX ? 
