# Exercice 1 - Questionnaire

1. Quelles sont, selon vous, les enjeux de l'utilisation de la librairie React au sein d'un projet web ?
    Les enjeux de l'utilisation de la Librairie React sont :
    
        - gestion des etats du DOM baucoup plus rapide.
        - optimisation des opérations sur le DOM en utilisant un DOM virtuel.


2. Qu'est-ce que le JSX ? Quelle est sont rôle au sein d'un composant React ?
        
        JSX est une syntaxe spécialisée à React assez proche du XML. Il permet de mélanger HTML et JavaScript.


3. Quelle est le rôle de la méthode `render` ?
        
        Render permet de retourner du code react qui sera compilé en HTML.

