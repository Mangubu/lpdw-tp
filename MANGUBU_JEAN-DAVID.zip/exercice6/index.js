import React    from 'react-dom';
import ReactDOM from 'react-dom';
import todoList  from './components/todoList.jsx';

ReactDOM.render(
  <App />,
  document.getElementById('root')
);
