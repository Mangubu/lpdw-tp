/**
 * Created by mangubu on 04/04/2016.
 */
import React from 'react';
import Header  from './Header.jsx';

export default class App extends React.Component {

    render() {
        return (
            <Header title="test"/>
        );
    }
}
