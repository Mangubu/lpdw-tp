# Exercice 5 - State et binding

1. Comment puis-je définir le `state` par défaut d'un composant ?
    getInitialState

2. Quelle est la particularité du `state` dans un composant React ?
    le state est une propriété de 'props'                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            

3. Comment puis-je transférer la référence de mon objet (this) à une méthode lorsque j'utilise les attributs natif d'un élément tel que `onChange` ou `onClick` par exemple ?
    avec 'handleChange'
4. Que ce passe t-il lorsqu'une propriété du `state` d'un composant React est modifiée ?
    Lorsque une propriété du state est modifié la  fonction  setState() est appelé.
