# Exercice 3 - Questions général

Voici une série de question (en vrac) sur ce que nous avons vu en cours. Elle ne sont pas directement liés à l'exercice mais elles peuvent vous aider à mieux comprendre l'environnement dans lequel sont executés les exercices.

1. Pouvez vous m'expliquez la fonction du fichier `index.js` ?

    index.js sert à lier le code jsx avec le fichier html

2. Quel est le rôle de webpack (en quelques mots/lignes) ?
    le webpack permet de  gérera aussi bien la transpilation des sources ES2015 et JSX

3. Quel est le rôle de babel ?
    Babel permet de transformer le javascript pour avoir la nouvelle syntax même si les navigateurs ne le supporte pas encore

4. Pourquoi devrais-je utilser tous ces outils alors que je pourrais me contenter d'un bloc-note et d'un navigateur ?
    Webpack permet d'organiser une application js en module et babel permet d'avoir les dernières normes du language javascript qui n'est pas forcément supporté par les différents navigateurs

5. Pouvez vous me citez d'autres outils utiles au dévelopement Front et ReactJS en particulier ?
