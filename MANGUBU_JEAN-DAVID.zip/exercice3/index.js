import React    from 'react';
import ReactDOM from 'react-dom';
import HelloWorld  from './components/Hello-World';

ReactDOM.render(
<HelloWorld name="Pebie" />,
    document.getElementById('root')
);
